<?php
return [
  'app' => [
    'debug' => true,

    // IMPORTANTE:
    // Como la API vive en https://TU_DOMINIO/api/..., el base_path debe ser '/api'
    'base_path' => '/api',
  ],

  'db' => [
    'host' => 'localhost',
    'name' => 'dboxetwvvztaxj',
    'user' => 'ufdhems9akpnl',
    'pass' => 'bvsmbm9legri',
    'charset' => 'utf8mb4',
  ],

  'jwt' => [
    'secret' => 'eec2d31510adecbcbf0b4d39ff457ac1a630f6eb7270f44217203c5ea319bc19',
    'issuer' => 'club-puerto-azul',
    'audience' => 'club-puerto-azul-web',
    'ttl_seconds' => 60 * 60 * 8,
  ],

'cors' => [
  'allowed_origins' => [
    'http://localhost:5173',
    'http://127.0.0.1:5173',

    // opcional (vite preview)
    'http://localhost:4173',
    'http://127.0.0.1:4173',
  ],
  'allowed_headers' => ['Content-Type', 'Authorization', 'X-API-Key'],
  'allowed_methods' => ['GET', 'POST', 'PATCH', 'OPTIONS'],
],

  // API keys para integraciones externas (NO usar en el browser)
  'api_keys' => [
    'botmaker' => '623cd39b8a1da51886cc8b9704b0230febdd232ecdba089ad153323aa35fabff',
  ],

  'notifications' => [
    'botmaker' => [
      'enabled' => true,
      'access_token' => 'eyJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJDb3Jwb3JhY2nDs24gS01HIGMuYS4iLCJidXNpbmVzc0lkIjoiY29ycG9yYWNpb25rbWdjYSIsIm5hbWUiOiJDb3Jwb3JhY2nDs24gS01HIGMuYS4iLCJhcGkiOnRydWUsImlkIjoiNkcwVFRFbXQ0S2RPanZxbDZ4Z2tsMGNTZ1lyMiIsImV4cCI6MTkzMTM4Njg0MiwianRpIjoiNkcwVFRFbXQ0S2RPanZxbDZ4Z2tsMGNTZ1lyMiJ9.NRLAYmjdbrnGRVUb7vonwx_OnhLEDcjga0wG4l2d_XthwLsQ3T1hj2vSGOO0VveParegEmfPmJcutz0IfpiMnw',
      'chat_channel_number' => '584227837862',
      'client_payload' => 'string',
      'timeout_seconds' => 10,
      'assigned_template' => 'plantilla_club',
      'not_assigned_template' => 'accion_asignado',
    ],
  ],  

  // Token para herramientas temporales (hash.php). Cambia y luego borras tools/hash.php
  'tools' => [
    'hash_token' => 'f61562105657fdcdcb1c08f88d4632d84e4d8294dc99ed8883cef46b17dde484',
  ],
];