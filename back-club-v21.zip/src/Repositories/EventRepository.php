<?php
declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class EventRepository
{
  private PDO $db;
  public function __construct(PDO $db) { $this->db = $db; }

  private function nowUtc(): string { return date('Y-m-d H:i:s'); }

  private function nowVE(): string { return $this->nowUtc(); }

  /** @return array<int, array<string,mixed>> */
  public function list(bool $includeInactive = false): array
  {
    $now = $this->nowVE();

    if ($includeInactive) {
      $sql = "SELECT id, code, name, start_date, end_date, active_from, inactive_at, created_at, updated_at
              FROM event_season
              ORDER BY id DESC";
      return $this->db->query($sql)->fetchAll();
    }

    $sql = "SELECT id, code, name, start_date, end_date, active_from, inactive_at, created_at, updated_at
            FROM event_season
            WHERE active_from <= ? AND (inactive_at IS NULL OR inactive_at > ?)
            ORDER BY id DESC";
    $st = $this->db->prepare($sql);
    $st->execute([$now, $now]);
    return $st->fetchAll();
  }

  public function getById(int $id): ?array
  {
    $sql = "SELECT id, code, name, start_date, end_date, active_from, inactive_at, created_at, updated_at
            FROM event_season
            WHERE id = ?
            LIMIT 1";
    $st = $this->db->prepare($sql);
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
  }

  public function create(array $data, int $actorUserId): int
  {
    $sql = "INSERT INTO event_season
              (code, name, start_date, end_date, active_from, inactive_at, created_at, updated_at, created_by, updated_by)
            VALUES
              (?, ?, ?, ?, ?, ?, NOW(), NOW(), ?, ?)";
    $st = $this->db->prepare($sql);
    $st->execute([
      $data['code'],
      $data['name'],
      $data['start_date'],
      $data['end_date'],
      $data['active_from'],
      $data['inactive_at'],
      $actorUserId,
      $actorUserId,
    ]);
    return (int)$this->db->lastInsertId();
  }

  public function patch(int $id, array $fields, int $actorUserId): void
  {
    $allowed = [
      'code' => 'code',
      'name' => 'name',
      'start_date' => 'start_date',
      'end_date' => 'end_date',
      'active_from' => 'active_from',
      'inactive_at' => 'inactive_at',
    ];

    $sets = [];
    $vals = [];
    foreach ($fields as $k => $v) {
      if (!isset($allowed[$k])) continue;
      $sets[] = $allowed[$k] . " = ?";
      $vals[] = $v;
    }

    if (count($sets) === 0) return;

    $sql = "UPDATE event_season SET " . implode(', ', $sets) . ", updated_at = NOW(), updated_by = ? WHERE id = ?";
    $vals[] = $actorUserId;
    $vals[] = $id;

    $st = $this->db->prepare($sql);
    $st->execute($vals);
  }
}
