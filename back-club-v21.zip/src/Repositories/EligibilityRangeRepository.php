<?php
declare(strict_types=1);

namespace App\Repositories;

use PDO;

final class EligibilityRangeRepository
{
  private PDO $db;
  public function __construct(PDO $db) { $this->db = $db; }

  private function nowUtc(): string { return date('Y-m-d H:i:s'); }

  private function nowVE(): string { return $this->nowUtc(); }

  /** @return array<int, array<string,mixed>> */
  public function listByDraw(int $drawId, bool $includeInactive = false): array
  {
    $now = $this->nowVE();
    if ($includeInactive) {
      $sql = "SELECT id, draw_id, range_from_action, range_to_action, label, active_from, inactive_at, created_at, updated_at
              FROM draw_eligibility_range
              WHERE draw_id = ?
              ORDER BY id ASC";
      $st = $this->db->prepare($sql);
      $st->execute([$drawId]);
      return $st->fetchAll();
    }

    $sql = "SELECT id, draw_id, range_from_action, range_to_action, label, active_from, inactive_at, created_at, updated_at
            FROM draw_eligibility_range
            WHERE draw_id = ?
              AND active_from <= ?
              AND (inactive_at IS NULL OR inactive_at > ?)
            ORDER BY id ASC";
    $st = $this->db->prepare($sql);
    $st->execute([$drawId, $now, $now]);
    return $st->fetchAll();
  }

  public function getById(int $id): ?array
  {
    $sql = "SELECT id, draw_id, range_from_action, range_to_action, label, active_from, inactive_at, created_at, updated_at
            FROM draw_eligibility_range
            WHERE id = ?
            LIMIT 1";
    $st = $this->db->prepare($sql);
    $st->execute([$id]);
    $row = $st->fetch();
    return $row ?: null;
  }

  public function create(int $drawId, array $data, int $actorUserId): int
  {
    $sql = "INSERT INTO draw_eligibility_range
              (draw_id, range_from_action, range_to_action, label, active_from, inactive_at, created_at, updated_at, created_by, updated_by)
            VALUES
              (?, ?, ?, ?, ?, ?, NOW(), NOW(), ?, ?)";
    $st = $this->db->prepare($sql);
    $st->execute([
      $drawId,
      (int)$data['range_from_action'],
      (int)$data['range_to_action'],
      $data['label'],
      (string)$data['active_from'],
      $data['inactive_at'],
      $actorUserId,
      $actorUserId,
    ]);
    return (int)$this->db->lastInsertId();
  }

  public function patch(int $id, array $fields, int $actorUserId): void
  {
    $allowed = [
      'range_from_action' => 'range_from_action',
      'range_to_action' => 'range_to_action',
      'label' => 'label',
      'active_from' => 'active_from',
      'inactive_at' => 'inactive_at',
    ];

    $sets = [];
    $vals = [];
    foreach ($fields as $k => $v) {
      if (!isset($allowed[$k])) continue;
      $sets[] = $allowed[$k] . ' = ?';
      $vals[] = $v;
    }
    if (count($sets) === 0) return;

    $sql = 'UPDATE draw_eligibility_range SET ' . implode(', ', $sets) . ', updated_at = NOW(), updated_by = ? WHERE id = ?';
    $vals[] = $actorUserId;
    $vals[] = $id;

    $st = $this->db->prepare($sql);
    $st->execute($vals);
  }
}
